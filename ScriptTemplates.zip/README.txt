these go in 
...\\UnityEditorInstallVersion\\Editor\\Data\\Resources\\ScriptTemplates

They are only loaded when Unity is started, so if you make changes or add new ones, you need to restart Unity to see the effects.

e.g.
83-subFolder__deepersubfolder-fileName.cs.txt
preceding number is sort order

#NOTRIM# to preserve blank lines.
#SCRIPTNAME# to reference name of script.